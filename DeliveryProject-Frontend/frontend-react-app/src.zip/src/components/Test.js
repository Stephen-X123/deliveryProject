import React from 'react';

class Test extends React.Component {

  render() {
    return (
        <h1 style={{textAlign: "center"}}>
            Wonderful! You've routed to a new page!
        </h1>
    )
  }
}

export default Test;