import React from 'react'
import '../css/Profile.css'

export default class Profile extends React.Component {
  render() {
    return (
      <div className="profile-history-background">
        <h1 className="order-history-title">
          Edit Personal Information
        </h1>
      </div>
    );
  }
}